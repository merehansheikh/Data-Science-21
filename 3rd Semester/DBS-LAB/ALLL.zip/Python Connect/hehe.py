import mysql.connector as sql

db = sql.connect(
host="localhost",
user="root",
password="rajpootchauhan")