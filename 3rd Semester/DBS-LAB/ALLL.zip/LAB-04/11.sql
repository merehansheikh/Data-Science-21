use bsdsf21a007;
select concat(ename, ' is workins as ', title) as Des
from employee
order by ename;