use employee;
select count(distinct mgr), count(distinct deptno)
from employee