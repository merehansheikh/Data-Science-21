use employee; 
select *
from employee, dept
