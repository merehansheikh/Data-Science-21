use bsdsf21a007;
describe employee;
select length(ename) as 'Length of Name'
from employee;