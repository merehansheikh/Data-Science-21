select instr(ename, 'a') as 'Name'
from employee
where ename like 'a%';