select lower (ename)
from employee
