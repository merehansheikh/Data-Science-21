use employee;

select adddate(current_date , interval 6 year)
from employee;
