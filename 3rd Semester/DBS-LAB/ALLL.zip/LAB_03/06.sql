select instr(ename, 'i') as 'Name'
from employee
where ename like '%i%';