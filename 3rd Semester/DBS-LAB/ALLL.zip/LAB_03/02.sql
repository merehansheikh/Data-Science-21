select upper(ename) as Upper
from employee;