use employee;

select ename
from employee
where mgr is null; 