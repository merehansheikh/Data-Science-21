use employee;

select YEAR(current_date) - year(HIREDATE)
from employee;
