select concat(ename, ' is working as an ', title) as'Profession'
from employee
where ename = 'John'