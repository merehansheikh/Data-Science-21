select upper(resp ) as 'Baray Characters'
from asg