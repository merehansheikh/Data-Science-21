class Node:
	def __init__(self, data, link=None):
		self.data = data
		self.link = link

def addFrontNode(lnkNodes, val):
	# as no loops, so no need of recursion
	tmp = Node(val)
	tmp.link = lnkNodes
	lnkNodes = tmp
	return lnkNodes

def printLinkedNodes(lnkNodes):
	if lnkNodes == None:
		return
	print(lnkNodes.data, end=" ")
	printLinkedNodes(lnkNodes.link)

def addBackNode(lnkNodes, val):
	if lnkNodes.link == None:
		lnkNodes.link = Node(val)
		return
	addBackNode(lnkNodes.link, val)

# unable to add first node, how can we manage it	
def removeNode(lnkNodes, val):
	if lnkNodes.link == None:
		return lnkNodes
	if lnkNodes.data == val:
		tmp = lnkNodes.link
		lnkNodes = tmp.link
		del tmp
		return lnkNodes
	return removeNode(lnkNodes.link, val)
	
def main():
	nodeSet1 = Node(125)
	printLinkedNodes(nodeSet1)
	print()
	nodeSet2 = Node(34)
	printLinkedNodes(nodeSet2)
	print()
	addBackNode(nodeSet2, 43)
	printLinkedNodes(nodeSet2)
	print()
	addBackNode(nodeSet2, 61)
	addBackNode(nodeSet2, 32)
	addBackNode(nodeSet2, 93)
	addBackNode(nodeSet1, 526)
	printLinkedNodes(nodeSet1)
	print()
	printLinkedNodes(nodeSet2)
	print()
	removeNode(nodeSet2,61)
	printLinkedNodes(nodeSet2)
	print()
	nodeSet2 = addFrontNode(nodeSet2, -7)  # why not working
	printLinkedNodes(nodeSet2)
	print()
	# Following code is approimately as that of addFrontNode
	tmp = Node(-2)   # why working
	tmp.link = nodeSet2
	nodeSet2 = tmp
	#--------
	printLinkedNodes(nodeSet2)
	print()
	printLinkedNodes(nodeSet1)
	print()

main()

